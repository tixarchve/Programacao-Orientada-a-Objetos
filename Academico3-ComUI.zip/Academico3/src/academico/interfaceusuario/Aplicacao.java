package academico.interfaceusuario;

import java.util.*;
import academico.entidades.*;

public class Aplicacao {
    private List<Universidade> universidades = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void executar() {
        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Criar universidade");
            System.out.println("2. Criar curso e grade curricular");
            System.out.println("3. Matricular aluno em curso");
            System.out.println("4. Ofertar turma");
            System.out.println("5. Matricular aluno em turma");
            System.out.println("6. Registrar nota/resultado");
            System.out.println("7. Imprimir histórico do aluno");
            System.out.println("8. Resultados de uma turma");
            System.out.println("9. Estatísticas de um curso");
            System.out.println("10. Estatísticas da universidade");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = //Integer.parseInt(scanner.nextLine());
                    scanner.nextInt();

            switch (opcao) {
                case 1 -> this.criarUniversidade();
                case 2 -> criarCurso();
                case 3 -> matricularAlunoCurso();
                case 4 -> ofertarTurma();
                case 5 -> matricularAlunoTurma();
                case 6 -> registrarResultado();
                case 7 -> imprimirHistorico();
                case 8 -> resultadosTurma();
                case 9 -> estatisticasCurso();
                case 10 -> estatisticasUniversidade();
            }
        } while (opcao != 0);
    }

    private Universidade buscarUniversidade(String nome) {
        for (Universidade u : universidades) {
            if (u.getNome().equalsIgnoreCase(nome)) return u;
        }
        return null;
    }

    private Curso buscarCurso(Universidade u, String nomeCurso) {
        for (Curso c : u.getCursos()) {
            if (c.getNome().equalsIgnoreCase(nomeCurso)) return c;
        }
        return null;
    }

    private Disciplina buscarDisciplina(Curso c, String nome) {
        for (Disciplina d : c.getGrade().getDisciplinas()) {
            if (d.getNome().equalsIgnoreCase(nome)) return d;
        }
        return null;
    }

    private Aluno buscarAluno(Curso c, String nome) {
        for (Aluno a : c.getAlunos()) {
            if (a.getNome().equalsIgnoreCase(nome)) return a;
        }
        return null;
    }

    private void criarUniversidade() {
        System.out.print("Nome da universidade: ");
        String nome = scanner.nextLine();
        universidades.add(new Universidade(nome));
        System.out.println("academico.entidades.Universidade criada.");
    }

    private void criarCurso() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) {
            System.out.println("academico.entidades.Universidade não encontrada.");
            return;
        }
        System.out.print("Nome do curso: ");
        Curso c = new Curso(scanner.nextLine());
        u.adicionarCurso(c);

        System.out.print("Quantas disciplinas na grade? ");
        int qtd = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < qtd; i++) {
            System.out.print("Nome da disciplina: ");
            c.adicionarDisciplina(new Disciplina(scanner.nextLine()));
        }
        System.out.println("academico.entidades.Curso e grade criados.");
    }

    private void matricularAlunoCurso() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("Nome do aluno: ");
        Aluno a = new Aluno(scanner.nextLine());
        c.adicionarAluno(a);
        System.out.println("Aluno matriculado.");
    }

    private void ofertarTurma() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("academico.entidades.Disciplina: ");
        Disciplina d = buscarDisciplina(c, scanner.nextLine());
        if (d == null) {
            System.out.println("academico.entidades.Disciplina não encontrada na grade.");
            return;
        }

        System.out.print("Ano: ");
        int ano = Integer.parseInt(scanner.nextLine());
        System.out.print("Semestre: ");
        int semestre = Integer.parseInt(scanner.nextLine());
        Turma t = new Turma(ano, semestre, d);
        d.adicionarTurma(t);
        System.out.println("academico.entidades.Turma ofertada.");
    }

    private void matricularAlunoTurma() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("Aluno: ");
        Aluno a = buscarAluno(c, scanner.nextLine());
        if (a == null) {
            System.out.println("Aluno não encontrado.");
            return;
        }

        System.out.print("academico.entidades.Disciplina: ");
        Disciplina d = buscarDisciplina(c, scanner.nextLine());
        if (d == null) return;

        if (d.getTurmas().isEmpty()) {
            System.out.println("Nenhuma turma ofertada.");
            return;
        }

        Turma t = d.getTurmas().getLast();
        Matricula m = new Matricula(a, t);
        t.adicionarMatricula(m);
        a.adicionarMatricula(m);
        System.out.println("Aluno matriculado na turma.");
    }

    private void registrarResultado() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("Aluno: ");
        Aluno a = buscarAluno(c, scanner.nextLine());
        if (a == null) return;

        System.out.print("academico.entidades.Disciplina: ");
        Disciplina d = buscarDisciplina(c, scanner.nextLine());
        if (d == null) return;

        for (Matricula m : a.getHistorico()) {
            if (m.getTurma().disciplina == d) {
                System.out.print("Nota (-1 para trancar): ");
                int nota = Integer.parseInt(scanner.nextLine());
                if (nota == -1)
                    m.trancar();
                else
                    m.definirNota(nota);
                System.out.println("Resultado registrado.");
                return;
            }
        }
        System.out.println("Matrícula não encontrada.");
    }

    private void imprimirHistorico() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("Aluno: ");
        Aluno a = buscarAluno(c, scanner.nextLine());
        if (a == null) return;

        for (Matricula m : a.getHistorico()) {
            System.out.println(m.getTurma().disciplina.getNome() + " - " + m.getStatus() + " - Nota: " + m.getNota());
        }
        System.out.println("Média geral: " + a.mediaGeral());
    }

    private void resultadosTurma() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.print("academico.entidades.Disciplina: ");
        Disciplina d = buscarDisciplina(c, scanner.nextLine());
        if (d == null || d.getTurmas().isEmpty()) return;

        Turma t = d.getTurmas().getLast();
        for (Matricula m : t.getMatriculas()) {
            System.out.println(m.getAluno().getNome() + ": " + m.getStatus() + " - " + m.getNota());
        }
        System.out.println("Média da turma: " + t.mediaNotas());
    }

    private void estatisticasCurso() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.print("academico.entidades.Curso: ");
        Curso c = buscarCurso(u, scanner.nextLine());
        if (c == null) return;

        System.out.println("Média geral do curso: " + c.mediaGeralCurso());
    }

    private void estatisticasUniversidade() {
        System.out.print("academico.entidades.Universidade: ");
        Universidade u = buscarUniversidade(scanner.nextLine());
        if (u == null) return;

        System.out.println("Média geral da universidade: " + u.mediaGeral());
    }
}