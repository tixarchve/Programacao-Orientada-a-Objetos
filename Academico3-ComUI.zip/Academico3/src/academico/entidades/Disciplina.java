package academico.entidades;

import java.util.*;

public class Disciplina {
    private String nome;
    private List<Turma> turmas;

    public Disciplina() {
        this.nome = "A ser definido";
        this.turmas = new ArrayList<>();
    }

    public Disciplina(String nome) {
        this.nome = nome;
        this.turmas = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void adicionarTurma(Turma t) {
        turmas.add(t);
    }

    public List<Turma> getTurmas() {
        return turmas;
    }

    public double mediaTurmaGeral() {
        int soma = 0, count = 0;
        for (Turma t : turmas) {
            double media = t.mediaNotas();
            if (media >= 0) {
                soma += media;
                count++;
            }
        }
        return count == 0 ? -1 : (double) soma / count;
    }
}