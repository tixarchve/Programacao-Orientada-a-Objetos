package academico.entidades;

import java.util.*;

public class Universidade {
    private String nome;
    private List<Curso> cursos = new ArrayList<>();

    public Universidade(String nome) {
        this.nome = nome;
    }

    public void adicionarCurso(Curso curso) {
        cursos.add(curso);
    }

    public String getNome() {
        return nome;
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    public double mediaGeral() {
        int soma = 0, count = 0;
        for (Curso c : cursos) {
            double media = c.mediaGeralCurso();
            if (media >= 0) {
                soma += media * c.getAlunos().size();
                count += c.getAlunos().size();
            }
        }
        return count == 0 ? -1 : (double) soma / count;
    }
}