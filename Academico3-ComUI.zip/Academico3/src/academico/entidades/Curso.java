package academico.entidades;

import java.util.*;

public class Curso {
    private String nome;
    private GradeCurricular grade;
    private List<Aluno> alunos = new ArrayList<>();

    public Curso(String nome) {
        this.nome = nome;
        this.grade = new GradeCurricular();
    }

    public String getNome() {
        return nome;
    }

    public void adicionarDisciplina(Disciplina d) {
        grade.adicionarDisciplina(d);
    }

    public GradeCurricular getGrade() {
        return grade;
    }

    public void adicionarAluno(Aluno aluno) {
        alunos.add(aluno);
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public double mediaGeralCurso() {
        int soma = 0, count = 0;
        for (Aluno a : alunos) {
            double m = a.mediaGeral();
            if (m >= 0) {
                soma += m;
                count++;
            }
        }
        return count == 0 ? -1 : (double) soma / count;
    }
}