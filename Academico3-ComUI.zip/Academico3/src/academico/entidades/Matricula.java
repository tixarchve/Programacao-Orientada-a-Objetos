package academico.entidades;

public class Matricula {
    private Aluno aluno;
    private Turma turma;
    private int nota;
    private String status;

    public Matricula(Aluno aluno, Turma turma) {
        this.aluno = aluno;
        this.turma = turma;
        this.status = "Cursando";
    }

    public Aluno getAluno() {
        return aluno;
    }

    public Turma getTurma() {
        return turma;
    }

    public int getNota() {
        return nota;
    }

    public String getStatus() {
        return status;
    }

    public void definirNota(int nota) {
        this.nota = nota;
        this.status = (nota >= 60) ? "Aprovado" : "Reprovado";
    }

    public void trancar() {
        this.status = "Trancado";
    }
}