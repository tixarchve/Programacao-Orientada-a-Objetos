package academico.entidades;
import java.util.*;

public class Aluno {
    private String nome;
    private List<Matricula> historico = new ArrayList<>();

    public Aluno(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void adicionarMatricula(Matricula m) {
        historico.add(m);
    }

    public List<Matricula> getHistorico() {
        return historico;
    }

    public double mediaGeral() {
        int soma = 0, count = 0;
        for (Matricula m : historico) {
            if (m.getStatus().equals("Aprovado") || m.getStatus().equals("Reprovado")) {
                soma += m.getNota();
                count++;
            }
        }
        return count == 0 ? -1 : (double) soma / count;
    }
}