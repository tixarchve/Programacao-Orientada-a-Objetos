package academico.entidades;

import java.util.*;

public class Turma {
    public int ano;
    public int semestre;
    public Disciplina disciplina;
    private List<Matricula> matriculas = new ArrayList<>();

    public Turma(int ano, int semestre, Disciplina disciplina) {
        this.ano = ano;
        this.semestre = semestre;
        this.disciplina = disciplina;
    }

    public void adicionarMatricula(Matricula m) {
        matriculas.add(m);
    }

    public List<Matricula> getMatriculas() {
        return matriculas;
    }

    public double mediaNotas() {
        int soma = 0, count = 0;
        for (Matricula m : matriculas) {
            if (m.getStatus().equals("Aprovado") || m.getStatus().equals("Reprovado")) {
                soma += m.getNota();
                count++;
            }
        }
        return count == 0 ? -1 : (double) soma / count;
    }
}