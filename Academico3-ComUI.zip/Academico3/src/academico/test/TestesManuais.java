package academico.test;

import academico.entidades.*;

public class TestesManuais {
    public void executarTestes() {
        System.out.println("Iniciando testes manuais do sistema acadêmico...");

        Universidade ufabc = new Universidade("UFABC");
        Curso eng = new Curso("Engenharia");
        ufabc.adicionarCurso(eng);

        Disciplina calculo = new Disciplina("Cálculo I");
        Disciplina fisica = new Disciplina("Física I");
        eng.adicionarDisciplina(calculo);
        eng.adicionarDisciplina(fisica);

        Aluno joao = new Aluno("João da Silva");
        eng.adicionarAluno(joao);

        Turma turmaCalculo = new Turma(2025, 1, calculo);
        Turma turmaFisica = new Turma(2025, 1, fisica);
        calculo.adicionarTurma(turmaCalculo);
        fisica.adicionarTurma(turmaFisica);

        Matricula m1 = new Matricula(joao, turmaCalculo);
        turmaCalculo.adicionarMatricula(m1);
        joao.adicionarMatricula(m1);

        Matricula m2 = new Matricula(joao, turmaFisica);
        turmaFisica.adicionarMatricula(m2);
        joao.adicionarMatricula(m2);

        m1.definirNota(75);  // aprovado
        m2.definirNota(45);  // reprovado

        // Teste de integração entre múltiplas universidades e cursos
        Universidade ufu = new Universidade("UFU");
        Curso comp = new Curso("Computação");
        ufu.adicionarCurso(comp);
        Disciplina prog = new Disciplina("Programação");
        comp.adicionarDisciplina(prog);
        Aluno ana = new Aluno("Ana Clara");
        comp.adicionarAluno(ana);
        Turma turmaProg = new Turma(2025, 2, prog);
        prog.adicionarTurma(turmaProg);
        Matricula m3 = new Matricula(ana, turmaProg);
        turmaProg.adicionarMatricula(m3);
        ana.adicionarMatricula(m3);
        m3.definirNota(95);

        System.out.println("\nHistórico de Ana:");
        for (Matricula m : ana.getHistorico()) {
            System.out.println(m.getTurma().disciplina.getNome() + " - " + m.getStatus() + " - Nota: " + m.getNota());
        }

        // Teste de exceção: média sem notas válidas
        Aluno vazio = new Aluno("SemNotas");
        System.out.println("Média geral de aluno sem notas: " + vazio.mediaGeral());

        // Teste de borda: nota 60
        Matricula mBorda = new Matricula(joao, turmaCalculo);
        mBorda.definirNota(60);
        System.out.println("Nota de corte (60) deve ser Aprovado: " + mBorda.getStatus());

        // Teste de borda: nota 0
        Matricula mZero = new Matricula(joao, turmaFisica);
        mZero.definirNota(0);
        System.out.println("Nota zero deve ser Reprovado: " + mZero.getStatus());

        // Teste de trancamento
        Matricula mTrancada = new Matricula(joao, turmaProg);
        mTrancada.trancar();
        System.out.println("Matrícula trancada deve ser 'Trancado': " + mTrancada.getStatus());

        // Histórico do aluno
        System.out.println("\nHistórico de João:");
        for (Matricula m : joao.getHistorico()) {
            System.out.println(m.getTurma().disciplina.getNome() + " - " + m.getStatus() + " - Nota: " + m.getNota());
        }

        // Média geral do aluno
        System.out.println("Média geral do aluno: " + joao.mediaGeral());

        // Média por turma
        System.out.println("Média da turma de Cálculo: " + turmaCalculo.mediaNotas());
        System.out.println("Média da turma de Física: " + turmaFisica.mediaNotas());

        // Média do curso
        System.out.println("Média geral do curso: " + eng.mediaGeralCurso());

        // Média da universidade
        System.out.println("Média geral da universidade: " + ufabc.mediaGeral());
    }

    public static void main(String[] args) {
        new TestesManuais().executarTestes();
    }
}